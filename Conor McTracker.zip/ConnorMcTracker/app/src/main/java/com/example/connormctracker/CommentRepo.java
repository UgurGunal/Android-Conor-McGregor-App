package com.example.connormctracker;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicInteger;

public class CommentRepo {

    private AtomicInteger commentid = new AtomicInteger(0);

    public CommentRepo() {
        // Constructor
    }


    public static String getCurrentDateTime() {
        // Get the current date and time
        Date currentDate = new Date();

        // Define the desired date format
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());

        // Format the date to a string
        return dateFormat.format(currentDate);
    }

    public void saveComment(String fightid, String username, String comment, ExecutorService srv, Handler uiHandler) {
        srv.submit(() -> {
            try {
                int currentCommentId = commentid.incrementAndGet();

                // Create a JSON object from the Comment object
                JSONObject commentJson = new JSONObject();
                commentJson.put("commentId", commentid);
                commentJson.put("fightId", fightid);
                commentJson.put("userName", username);
                commentJson.put("date", getCurrentDateTime());
                commentJson.put("comment", comment);

                URL url = new URL("http://10.0.2.2:8080/connor/comment/save");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                // Set the request method to POST
                conn.setRequestMethod("POST");

                // Set the content type
                conn.setRequestProperty("Content-Type", "application/json");

                // Enable input/output streams
                conn.setDoOutput(true);
                conn.setDoInput(true);

                // Write the JSON object to the output stream
                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = commentJson.toString().getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int responseCode = conn.getResponseCode();

                // Check if the request was successful
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    Message msg = new Message();
                    msg.obj = "Comment saved successfully";
                    uiHandler.sendMessage(msg);
                } else {
                    Message msg = new Message();
                    msg.obj = "Error saving comment";
                    uiHandler.sendMessage(msg);
                }

            } catch (MalformedURLException e) {
                Log.e("CommentRepo", e.getMessage());
            } catch (IOException | JSONException e) {
                Log.e("CommentRepo", e.getMessage());
            }
        });
    }

    public void getCommentsById(String ID, ExecutorService srv, Handler uiHandler) {
        srv.submit(() -> {
            try {
                List<Comment> data = new ArrayList<>();

                URL url =
                        new URL("http://10.0.2.2:8080/connor/comment/" + ID);


                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                BufferedReader reader
                        = new BufferedReader(
                        new InputStreamReader(
                                conn.getInputStream()));
                StringBuilder buffer = new StringBuilder();
                String line = "";
                while ((line = reader.readLine()) != null) {
                    buffer.append(line);
                }

                JSONArray arr = new JSONArray(buffer.toString());

                for (int i = 0; i < arr.length(); i++) {

                    JSONObject current = arr.getJSONObject(i);

                    Comment comment = new Comment(
                            current.getString("commentId"),
                            current.getString("fightId"),
                            current.getString("userName"),
                            current.getString("date"),
                            current.getString("comment")
                            );
                    data.add(comment);
                }

                Message msg = new Message();
                msg.obj = data;
                uiHandler.sendMessage(msg);


            } catch (MalformedURLException e) {
                Log.e("DEV", e.getMessage());
            } catch (IOException e) {
                Log.e("DEV", e.getMessage());
            } catch (JSONException e) {
                Log.e("DEV", e.getMessage());
            }
        });
    }
}