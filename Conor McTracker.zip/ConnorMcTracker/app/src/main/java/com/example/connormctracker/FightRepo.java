package com.example.connormctracker;

        import android.os.Handler;
        import android.os.Message;
        import android.util.Log;

        import org.json.JSONArray;
        import org.json.JSONException;
        import org.json.JSONObject;

        import java.io.BufferedReader;
        import java.io.IOException;
        import java.io.InputStreamReader;
        import java.net.HttpURLConnection;
        import java.net.MalformedURLException;
        import java.net.URL;
        import java.util.ArrayList;
        import java.util.List;
        import java.util.Objects;
        import java.util.concurrent.ExecutorService;

        import javax.net.ssl.HttpsURLConnection;

public class FightRepo {

    public FightRepo() {

    }

    public List<Fight> getSampleFightList() {
        List<Fight> fightList = new ArrayList<>();

        // Adding sample fights
        fightList.add(new Fight("1", "1", "Armbar", 1, "2022-01-01", 2022, "Fight 1", "fighter1", "opponent1", "Stat1", true));
        fightList.add(new Fight("2", "2", "Triangle Choke", 2, "2022-02-01", 2022, "Fight 2", "fighter2", "opponent2", "Stat2", false));
        fightList.add(new Fight("3", "3", "Knockout", 3, "2022-03-01", 2022, "CONNOR", "fighter3", "opponent3", "Stat3", true));
        fightList.add(new Fight("4", "4", "Rear Naked Choke", 4, "2022-04-01", 2022, "Fight 4", "fighter4", "opponent4", "Stat4", false));
        fightList.add(new Fight("5", "5", "Guillotine Choke", 5, "2022-05-01", 2022, "DENEME VS DENEME", "fighter5", "opponent5", "Stat5", true));
        fightList.add(new Fight("5", "5", "Guillotine Choke", 5, "2022-05-01", 2022, "Fight 3131", "fighter5", "opponent5", "Stat5", true));
        fightList.add(new Fight("5", "5", "Guillotine Choke", 5, "2022-05-01", 2022, "Fight 5", "fighter5", "opponent5", "Stat5", true));

        return fightList;
    }

    public void getFightsBetweenYears(int startYear, int endYear, ExecutorService srv, Handler uiHandler) {
        srv.submit(() -> {
            try {
                List<Fight> data = new ArrayList<>();

                URL url =
                        new URL("http://10.0.2.2:8080/connor/fight/byyear/" + startYear + "/" + endYear);


                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                BufferedReader reader
                        = new BufferedReader(
                        new InputStreamReader(
                                conn.getInputStream()));
                StringBuilder buffer = new StringBuilder();
                String line = "";
                while ((line = reader.readLine()) != null) {
                    buffer.append(line);
                }

                JSONArray arr = new JSONArray(buffer.toString());

                for (int i = 0; i < arr.length(); i++) {

                    JSONObject current = arr.getJSONObject(i);

                    Fight fight = new Fight(
                            current.getString("fightId"),
                            current.getString("submission"),
                            current.getInt("round"),
                            current.getString("date"),
                            current.getInt("year"),
                            current.getString("fightName"),
                            current.getString("fighterId"),
                            current.getString("opponentName"),
                            current.getString("preFightStat"),
                            current.getBoolean("win")
                    );
                    data.add(fight);
                }

                Message msg = new Message();
                msg.obj = data;
                uiHandler.sendMessage(msg);


            } catch (MalformedURLException e) {
                Log.e("DEV", e.getMessage());
            } catch (IOException e) {
                Log.e("DEV", e.getMessage());
            } catch (JSONException e) {
                Log.e("DEV", e.getMessage());
            }


        });
    }

    public void getFightbyID(String ID, ExecutorService srv, Handler uiHandler) {
        srv.execute(() -> {
            try {
                URL url = new URL("http://10.0.2.2:8080/connor/fight/byid/" + ID);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder buffer = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    buffer.append(line);
                }

                JSONObject current = new JSONObject(buffer.toString());
                Fight fight = new Fight(
                        current.getString("fightId"),
                        current.getString("submission"),
                        current.getInt("round"),
                        current.getString("date"),
                        current.getInt("year"),
                        current.getString("fightName"),
                        current.getString("fighterId"),
                        current.getString("opponentName"),
                        current.getString("preFightStat"),
                        current.getBoolean("win"));

                Message msg = new Message();
                msg.obj = fight;
                uiHandler.sendMessage(msg);

            } catch (IOException | JSONException e) {
                // Handle the exceptions (log, show error message, etc.)
                Log.e("DEV", e.getMessage());
            }
        });
    }

}
