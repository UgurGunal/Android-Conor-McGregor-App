package com.example.connormctracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.concurrent.ExecutorService;

public class CommentActivity extends AppCompatActivity {

    private String fightId;
    private EditText usernameText;
    private EditText commentText;
    private Button postCommentButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comment);
        usernameText = findViewById(R.id.usernameText);
        commentText = findViewById(R.id.commentText);
        postCommentButton = findViewById(R.id.button);
        String fightId = getIntent().getStringExtra("fightId");

        postCommentButton.setOnClickListener(v -> {
            // Retrieve username and comment text
            String username = usernameText.getText().toString();
            String comment = commentText.getText().toString();

            CommentRepo repo = new CommentRepo();
            ExecutorService srv = ((FightApplication) getApplication()).srv;

            repo.saveComment(fightId,username,comment,srv,null);
            Intent intent = new Intent(this, FightDetailsActivity.class);
            intent.putExtra("fightId", fightId);
            startActivity(intent);
        });
    }
}