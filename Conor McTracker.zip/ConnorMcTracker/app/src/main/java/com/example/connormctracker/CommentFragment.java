package com.example.connormctracker;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;
import java.util.concurrent.ExecutorService;

public class CommentFragment extends Fragment {


    private RecyclerView recView;
    private String fightId;

    public CommentFragment() {
        // Required empty public constructor
    }

    Handler commentHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            List<Comment> data = (List<Comment>) msg.obj;

            if (recView != null) {
                CommentAdapter adp = new CommentAdapter(requireContext(), data);
                recView.setAdapter(adp);
            } else {
                Log.e("FragmentCommentList", "RecyclerView is null");
            }

            return true;
        }
    });

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Check if arguments are not null
        if (getArguments() != null) {
            // Retrieve fightId from arguments
            fightId = getArguments().getString("fightId", "");
        }
    }


@Override
public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_comment, container, false);
        recView = view.findViewById(R.id.commentRecyclerView);

        // Use requireContext() to get the Context for the LinearLayoutManager
        recView.setLayoutManager(new LinearLayoutManager(requireContext()));

        CommentRepo repo = new CommentRepo();
        ExecutorService srv = ((FightApplication) requireActivity().getApplication()).srv;
        repo.getCommentsById(fightId, srv, commentHandler);

        return view;
        }
}

