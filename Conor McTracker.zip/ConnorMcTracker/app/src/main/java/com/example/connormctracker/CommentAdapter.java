package com.example.connormctracker;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CommentAdapter extends RecyclerView.Adapter<CommentAdapter.CommentViewHolder> {
    Context ctx;
    List<Comment> data;

    public CommentAdapter(Context ctx, List<Comment> data) {
        this.ctx = ctx;
        this.data = data;
    }

    @NonNull
    @Override
    public CommentAdapter.CommentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(ctx).inflate(R.layout.listitemcomment, parent, false);
        CommentAdapter.CommentViewHolder holder = new CommentAdapter.CommentViewHolder(view);
        holder.setIsRecyclable(false);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull CommentAdapter.CommentViewHolder holder, int position) {
        Comment comment = data.get(position);
        holder.username.setText(comment.getUserName());
        holder.comment.setText(comment.getComment());
        holder.date.setText(comment.getDate());

        // Set visibility of the thin line view
        if (position == data.size() - 1) {
            // If it's the last item, hide the thin line
            holder.thinLine.setVisibility(View.GONE);
        } else {
            // If it's not the last item, show the thin line
            holder.thinLine.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class CommentViewHolder extends RecyclerView.ViewHolder {
        TextView username;
        TextView comment;
        TextView date;
        ConstraintLayout row;
        View thinLine;

        public CommentViewHolder(@NonNull View itemView) {

            super(itemView);
            username = itemView.findViewById(R.id.username);
            comment = itemView.findViewById(R.id.comment);
            date = itemView.findViewById(R.id.commentDate);
            row = itemView.findViewById(R.id.commentRowLayout);
            thinLine = itemView.findViewById(R.id.commentThinLine);

        }
    }
}

