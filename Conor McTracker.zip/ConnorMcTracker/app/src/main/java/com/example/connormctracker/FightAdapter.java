package com.example.connormctracker;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class FightAdapter extends RecyclerView.Adapter<FightAdapter.FightViewHolder> {

    Context ctx;
    List<Fight> data;

    public FightAdapter(Context ctx, List<Fight> data) {
        this.ctx = ctx;
        this.data = data;
    }

    @NonNull
    @Override
    public FightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(ctx).inflate(R.layout.listitem, parent, false);
        FightViewHolder holder = new FightViewHolder(view);
        holder.setIsRecyclable(false);

        return holder;
    }


    @Override
    public void onBindViewHolder(@NonNull FightViewHolder holder, int position) {
        Fight fight = data.get(position);
        holder.textViewName.setText(fight.getFightName());
        holder.textViewDate.setText(String.valueOf(fight.getYear()));

        // Set visibility of the thin line view
        if (position == data.size() - 1) {
            // If it's the last item, hide the thin line
            holder.thinLine.setVisibility(View.GONE);
        } else {
            // If it's not the last item, show the thin line
            holder.thinLine.setVisibility(View.VISIBLE);
        }

        // Set click listener for the row
        holder.row.setOnClickListener(v -> {
            // Start the FightDetailsActivity
            Intent intent = new Intent(ctx, FightDetailsActivity.class);
            // Pass the fight ID to the new activity
            intent.putExtra("fightId", fight.getFightId());
            ctx.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class FightViewHolder extends RecyclerView.ViewHolder {
        TextView textViewName;
        TextView textViewDate;
        ImageView imageView;
        ConstraintLayout row;
        View thinLine;

        public FightViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.comment);
            textViewDate = itemView.findViewById(R.id.ListItemDate);
            row = itemView.findViewById(R.id.commentRowLayout);
            thinLine = itemView.findViewById(R.id.commentThinLine);

        }
    }
}
