package com.example.connormctracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;
import java.util.concurrent.ExecutorService;

public class FightDetailsActivity extends AppCompatActivity {

    TextView header;
    TextView date;
    TextView opponent;
    TextView stat;
    TextView win;
    TextView submission;
    TextView round;
    Button comment;

    String fightId;

    ImageView image;

    Handler dataHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            Fight fight = (Fight)msg.obj;
            date.setText(fight.getDate());
            opponent.setText(fight.getOpponentName());
            stat.setText(fight.getPreFightStat());
            win.setText(String.valueOf(fight.getWin()));
            submission.setText(fight.getSubmission());
            round.setText(String.valueOf(fight.getRound()));
            header.setText(fight.getFightName());

            return true;
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fight_details);

        image = findViewById(R.id.imageViewHeader);
        header = findViewById(R.id.Header);
        date = findViewById(R.id.DateInfo);
        opponent = findViewById(R.id.OpponentInfo);
        stat = findViewById(R.id.PreFightInfo);
        win = findViewById(R.id.WinInfo);
        submission = findViewById(R.id.SubmissionInfo);
        round = findViewById(R.id.RoundInfo);
        comment = findViewById(R.id.commentButton);

        // Assuming fightId is a String variable in your FightDetailsActivity
        fightId = getIntent().getStringExtra("fightId");
        CommentFragment commentFragment = new CommentFragment();
        Bundle bundle = new Bundle();
        bundle.putString("fightId", fightId);
        commentFragment.setArguments(bundle);

        getSupportFragmentManager().beginTransaction().replace(R.id.commentContainer, commentFragment).commit();

        FightRepo repo = new FightRepo();
        ExecutorService srv = ((FightApplication) this.getApplication()).srv;
        repo.getFightbyID(fightId, srv, dataHandler);

        comment.setOnClickListener(v -> {
            // Create a new Intent
            Intent intent = new Intent(FightDetailsActivity.this, CommentActivity.class);

            // Pass the FightId to the new activity
            intent.putExtra("fightId", fightId);

            // Start the new activity
            startActivity(intent);
        });

    }
}