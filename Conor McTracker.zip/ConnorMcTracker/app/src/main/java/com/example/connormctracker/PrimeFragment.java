package com.example.connormctracker;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;
import java.util.concurrent.ExecutorService;


public class PrimeFragment extends Fragment {

    private RecyclerView recView;
    private int startYear;
    private int endYear;

    public PrimeFragment() {
        // Required empty public constructor
    }

    Handler dataHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            List<Fight> data = (List<Fight>) msg.obj;

            if (recView != null) {
                FightAdapter adp = new FightAdapter(requireContext(), data);
                recView.setAdapter(adp);
            } else {
                Log.e("FragmentFightList", "RecyclerView is null");
            }

            return true;
        }
    });


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_prime, container, false);
        recView = view.findViewById(R.id.RecyclerViewPrime);

        recView.setLayoutManager(new LinearLayoutManager(requireContext()));

        FightRepo repo = new FightRepo();
        ExecutorService srv = ((FightApplication) requireActivity().getApplication()).srv;
        repo.getFightsBetweenYears(2014, 2016, srv, dataHandler);

        return view;
    }
}