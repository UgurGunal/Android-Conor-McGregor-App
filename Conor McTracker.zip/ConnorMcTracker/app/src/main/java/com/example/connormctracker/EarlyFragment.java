package com.example.connormctracker;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;
import java.util.concurrent.ExecutorService;


public class EarlyFragment extends Fragment {

    private RecyclerView recView;
    private int startYear;
    private int endYear;

    public EarlyFragment() {
        // Required empty public constructor
    }

    Handler dataHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            List<Fight> data = (List<Fight>) msg.obj;

            if (recView != null) {
                FightAdapter adp = new FightAdapter(requireContext(), data);
                recView.setAdapter(adp);
            } else {
                Log.e("FragmentFightList", "RecyclerView is null");
            }

            return true;
        }
    });


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_early, container, false);
        recView = view.findViewById(R.id.RecyclerViewEarly);

        // Use requireContext() to get the Context for the LinearLayoutManager
        recView.setLayoutManager(new LinearLayoutManager(requireContext()));

        FightRepo repo = new FightRepo();
        ExecutorService srv = ((FightApplication) requireActivity().getApplication()).srv;
        repo.getFightsBetweenYears(2007, 2013, srv, dataHandler);

        return view;
    }

}

