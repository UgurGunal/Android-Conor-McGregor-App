package com.main.web.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Fight {

	@Id 
	public String _id;
	public String fightId;
	public String submission;
	public int round;
	public String date;
	public int year;
	public String fightName;
	public String fighterId;
	public String opponentName;
	public String preFightStat;
	public Boolean win;
	
	public Fight() {}

	public Fight(String _id, String fightId, String submission, int round, String date, int year, String fightName,
			String fighterId, String opponentName, String preFightStat, Boolean win) {
		super();
		this._id = _id;
		this.fightId = fightId;
		this.submission = submission;
		this.round = round;
		this.date = date;
		this.year = year;
		this.fightName = fightName;
		this.fighterId = fighterId;
		this.opponentName = opponentName;
		this.preFightStat = preFightStat;
		this.win = win;
	}

	public Fight(String fightId, String submission, int round, String date, int year, String fightName,
			String fighterId, String opponentName, String preFightStat, Boolean win) {
		super();
		this.fightId = fightId;
		this.submission = submission;
		this.round = round;
		this.date = date;
		this.year = year;
		this.fightName = fightName;
		this.fighterId = fighterId;
		this.opponentName = opponentName;
		this.preFightStat = preFightStat;
		this.win = win;
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public String getFightId() {
		return fightId;
	}

	public void setFightId(String fightId) {
		this.fightId = fightId;
	}

	public String getSubmission() {
		return submission;
	}

	public void setSubmission(String submission) {
		this.submission = submission;
	}

	public int getRound() {
		return round;
	}

	public void setRound(int round) {
		this.round = round;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getFightName() {
		return fightName;
	}

	public void setFightName(String fightName) {
		this.fightName = fightName;
	}

	public String getFighterId() {
		return fighterId;
	}

	public void setFighterId(String fighterId) {
		this.fighterId = fighterId;
	}

	public String getOpponentName() {
		return opponentName;
	}

	public void setOpponentName(String opponentName) {
		this.opponentName = opponentName;
	}

	public String getPreFightStat() {
		return preFightStat;
	}

	public void setPreFightStat(String preFightStat) {
		this.preFightStat = preFightStat;
	}

	public Boolean getWin() {
		return win;
	}

	public void setWin(Boolean win) {
		this.win = win;
	}

	
	
}
