package com.main.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConnorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConnorApplication.class, args);
	}

}
